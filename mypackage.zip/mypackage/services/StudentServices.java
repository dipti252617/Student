package mypackage.services;
import java.util.*;
import mypackage.repository.*;
import mypackage.model.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServices
{
     @Autowired
     IStudentRepository serpo;
     
     public Student AddUpdateStudent(Student s)
     {
    	 return serpo.save(s);
     }
     
     public List<Student>GetStudents()
     {
    	 return serpo.findAll();
     }
     public Student GetStudent(int id)
     {
    	 return serpo.findById(id).get();
     }
     public Student DeleteStudent(int id)
     {
    	 Student s=GetStudent(id);
    	 serpo.delete(s);
    	 return s;
     }
}

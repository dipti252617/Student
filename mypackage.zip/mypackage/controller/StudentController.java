package mypackage.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import mypackage.model.*;
import mypackage.services.*;

@RestController
@CrossOrigin(origins = "*",methods= {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST,RequestMethod.DELETE},allowedHeaders = "*")

public class StudentController
{
    @Autowired
    StudentServices sservice;
    
    @GetMapping("api/student")
    public List<Student>GetStudents()
    {
    	return sservice.GetStudents();
    	
    }
    
    @GetMapping("api/student/{id}")
    public Student GetStudent(@PathVariable("id")int roll_no)
    {
    	return sservice.GetStudent(roll_no);
    }
    
    @PostMapping("api/student")
    public Student AddStudent(@RequestBody Student s)
    {
    	return sservice.AddUpdateStudent(s);
    	
    }
    
    @PutMapping("api/student")
    public Student UpdateStudent(@RequestBody Student s)
    {
    	return sservice.AddUpdateStudent(s);
    }
    
    @DeleteMapping("api/student/{id}")
    public Student DeleteStudent(@PathVariable("id")int roll_no)
    {
    	return sservice.DeleteStudent(roll_no);
    }
    
}

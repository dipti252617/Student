package mypackage.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_student")
public class Student 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
   private int roll_no;
   private String name;
   private String qualifiactions;
   private float percentage;
   
//Generate Constructors from superclass
public Student() {
	super();
	// TODO Auto-generated constructor stub
}

//Generate Constructor using fields
public Student(int roll_no, String name, String qualifiactions, float percentage) {
	super();
	this.roll_no = roll_no;
	this.name = name;
	this.qualifiactions = qualifiactions;
	this.percentage = percentage;
}
public int getRoll_no() {
	return roll_no;
}

//Generate Getter and Setter Methods for the type's fields
public void setRoll_no(int roll_no) {
	this.roll_no = roll_no;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getQualifiactions() {
	return qualifiactions;
}
public void setQualifiactions(String qualifiactions) {
	this.qualifiactions = qualifiactions;
}
public float getPercentage() {
	return percentage;
}
public void setPercentage(float percentage) {
	this.percentage = percentage;
}
}
